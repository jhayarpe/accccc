<?php
require_once 'config.inc.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $pwd = $_POST["pwd"];

    if(empty($username)){
        $_SESSION['errors']['username']= 'Username is required.';
    }
    if(empty($password)){
        $_SESSION['errors']['password']= 'Password is required.';
    }
    if(isset($_SESSION['errors'])) {
        header("Location: ../login.php");
        // unset($_SESSION['errors']);
        exit();
    }
        try {
            require_once "dbc.inc.php";

            $query = "SELECT * FROM users WHERE username = :username AND pwd = :pwd;";

            $stmt = $pdo->prepare($query);

            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":pwd", $pwd);

            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                $pdo = null;
                $stmt = null;

                header("Location: ../index.php");
                die();
            } else {
                echo "Username or password doesn't match";
            }
        } catch (PDOException $e) {
            die("Query failed: " . $e->getMessage());
        }
} else {
    header("Location: ../index.php");
}