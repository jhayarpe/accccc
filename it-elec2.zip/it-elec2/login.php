<?php
require_once 'includes/config.inc.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            box-sizing: border-box;
            padding: 0;
            margin: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            max-width: 960px;
            margin: 0 auto;
            padding: 20px;
        }

        .navigation {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .navigation a {
            text-decoration: none;
            color: #333;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 0 10px;
            transition: background-color 0.3s;
        }

        .navigation a:hover {
            background-color: #5ab89c;
            color: white;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .input-container {
            margin-bottom: 10px;
        }

        .input-container input[type="text"],
        .input-container input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #5ab89c;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        button:hover {
            background-color: #3f7e63;
        }

        .form-wrapper {
            max-width: 360px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="navigation">
            <a href="index.php">Home</a>
            <a href="comments.php">Comments</a>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
        </div>
    </div>
    <div class="form-wrapper">
        <h2>Login</h2>
        <form action="includes/login.inc.php" method="post">
            <div class="input-container">
                <input value = "<?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : '' ?>" type="text" name="username" placeholder="Username" <?= isset($_SESSION['errors']['username']) ? 'style="border: 1px solid red;"' : '' ?>><br>
                <?= isset($_SESSION['errors']['username']) ? $_SESSION['errors']['username'] : '' ?>
            </div>
            <div class="input-container">
                <input type="password" name="pwd" placeholder="Password">
            </div>
            <button type="submit">Login</button>
        </form>
    </div>
</body>

</html>
