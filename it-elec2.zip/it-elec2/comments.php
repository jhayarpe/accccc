<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comment Section</title>
    <style>
        * {
            box-sizing: border-box;
            padding: 0;
            margin: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            max-width: 960px;
            margin: 0 auto;
            padding: 20px;
        }

        .navigation {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .navigation a {
            text-decoration: none;
            color: #333;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 0 10px;
            transition: background-color 0.3s;
        }

        .navigation a:hover {
            background-color: #5ab89c;
            color: white;
        }

        .commentsForm {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 600px; 
            margin: 0 auto; 
        }

        .commentsForm form {
            display: flex;
            flex-direction: column; 
        }

        .commentsForm select,
        .commentsForm textarea {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%; 
            max-width: 560px; 
        }

        .commentsForm button {
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #5ab89c;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%; 
            max-width: 560px;
        }

        .commentsForm button:hover {
            background-color: #3f7e63;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="navigation">
            <a href="index.php" class="home">HOME</a>
            <a href="comments.php" class="comments">COMMENTS</a>
            <a href="register.php" class="Register">REGISTER</a>
            <a href="login.php" class="login">LOGIN</a>
        </div>

        <div class="commentsForm">
            <form action="includes/comments.inc.php" method="post">
                <select name="user">
                    <?php foreach ($results as $rows): ?>
                        <option value="<?= $rows['id']?>"><?= htmlspecialchars($rows['username']) ?></option>
                    <?php endforeach; ?>
                </select><br />
                <textarea name="comments" placeholder="Enter your comments"></textarea><br />
                <button type="submit">Submit</button>
            </form>
        </div>
    </div>
</body>

</html>
